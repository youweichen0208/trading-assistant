"""Fixed JSON worker for trusted adapters; accepts no code, paths or URLs."""
import json
import os
import sys
from . import PriceQuery, FinancialQuery, DataError, get_price_history, get_indicators, get_financials


def main():
    try:
        request = json.loads(sys.stdin.read(4097))
        if set(request) != {'operation','arguments'}:
            raise ValueError('invalid request')
        operation, args = request['operation'], request['arguments']
        if operation == 'financials':
            result = get_financials(FinancialQuery(**args),user_agent=os.environ.get('TRADING_SEC_USER_AGENT',''))
        elif operation in {'price_history','indicators'}:
            result = (get_price_history if operation == 'price_history' else get_indicators)(PriceQuery(**args))
        else:
            raise ValueError('invalid operation')
        print(json.dumps(result, allow_nan=False))
    except DataError as exc:
        print(json.dumps({'error':exc.code}))
    except (ValueError,TypeError,KeyError):
        print(json.dumps({'error':'invalid_arguments_or_provider_data'}))
    except Exception:
        print(json.dumps({'error':'provider_failed'}))


if __name__ == '__main__':
    main()
