from datetime import date
import math
from .models import PriceQuery, DataError, envelope
from .indicators import calculate_indicators


def yahoo_ticker(symbol):
    import yfinance as yf
    # Fail filesystem cache initialization; upstream falls back to its dummy cache.
    # This is a fixed invalid directory, not a caller-controlled filesystem path.
    yf.set_tz_cache_location('/dev/null/trading-core-cache-disabled')
    return yf.Ticker(symbol)


def get_price_history(query: PriceQuery, *, ticker_factory=yahoo_ticker):
    if not isinstance(query, PriceQuery):
        raise ValueError('PriceQuery required')
    try:
        ticker = ticker_factory(query.symbol)
        frame = ticker.history(start=query.start.isoformat(), end=query.end.isoformat(), interval='1d',
                               auto_adjust=False, back_adjust=False, repair=False, actions=False,
                               keepna=True, timeout=8, raise_errors=True)
        if frame is None or frame.empty:
            raise DataError('empty_result')
        meta = ticker.get_history_metadata()
        if (meta.get('currency') != 'USD' or meta.get('instrumentType') not in {'EQUITY', 'ETF'}
                or meta.get('exchangeName') not in {'NMS', 'NGM', 'NCM', 'NYQ', 'ASE', 'PCX', 'BTS', 'BATS'}
                or meta.get('exchangeTimezoneName') != 'America/New_York'):
            raise DataError('unsupported_market_or_missing_metadata')
        if frame.index.tz is None or len(frame) > 1830 or frame.index.has_duplicates or not frame.index.is_monotonic_increasing:
            raise DataError('invalid_price_data')
        def number(value):
            return float(value) if value is not None and math.isfinite(float(value)) else None
        rows = []
        for timestamp, row in frame.iterrows():
            day = timestamp.tz_convert(meta['exchangeTimezoneName']).date()
            if not query.start <= day < query.end:
                raise DataError('invalid_price_period')
            rows.append(dict(date=day.isoformat(), **{key: number(row[col]) for key,col in
                        [('open','Open'), ('high','High'), ('low','Low'), ('close','Close'),
                         ('adjusted_close','Adj Close'), ('volume','Volume')]}))
        result = envelope(query, 'Yahoo Finance via yfinance')
        result.update(currency=meta['currency'], timezone=meta['exchangeTimezoneName'],
                      period=dict(start=query.start.isoformat(), end_exclusive=query.end.isoformat(),
                                  first=rows[0]['date'], last=rows[-1]['date']), rows=rows,
                      adjustment='OHLC as delivered with auto_adjust=False (vendor may already split-adjust); '
                                 'adjusted_close is Yahoo Adj Close, including vendor dividend/split adjustments.')
        if any(row['adjusted_close'] is None for row in rows):
            result['warnings'].append('Missing adjusted closes; indicators will not bridge gaps.')
        return result
    except DataError:
        raise
    except Exception as exc:
        from yfinance.exceptions import YFRateLimitError
        raise DataError('rate_limited' if isinstance(exc, YFRateLimitError) else 'price_provider_failed') from None


def get_indicators(query: PriceQuery, *, ticker_factory=yahoo_ticker):
    result = get_price_history(query, ticker_factory=ticker_factory)
    rows = result.pop('rows')
    result['metrics'] = calculate_indicators([row['adjusted_close'] for row in rows])
    result['sample_size'] = len(rows)
    result['algorithm'] = 'v1: adjusted closes; Wilder RSI14 seeded by 14 changes (flat=50); SMA20/50/200; simple interval return; daily simple return sample std ddof=1 * sqrt(252); peak-relative max drawdown <=0; no gap filling'
    return result


def get_analysis(query: PriceQuery, *, ticker_factory=yahoo_ticker):
    """One history fetch; trend warmup never expands the requested performance window."""
    from datetime import timedelta
    history_query = PriceQuery(symbol=query.symbol, start=min(query.start, query.end-timedelta(days=400)), end=query.end)
    result = get_price_history(history_query, ticker_factory=ticker_factory)
    history = result['rows']
    rows = [row for row in history if query.start <= date.fromisoformat(row['date']) < query.end]
    if not rows:
        raise DataError('empty_result')
    metrics = calculate_indicators([row['adjusted_close'] for row in rows])
    trend = calculate_indicators([row['adjusted_close'] for row in history])
    for key in ('sma20', 'sma50', 'sma200', 'rsi14'):
        metrics[key] = trend[key]
    result['indicator_history'] = dict(result['period'], sample_size=len(history))
    result.update(rows=rows, metrics=metrics, sample_size=len(rows),
                  period=dict(start=query.start.isoformat(), end_exclusive=query.end.isoformat(),
                              first=rows[0]['date'], last=rows[-1]['date']),
                  algorithm='v2: SMA/RSI use indicator_history adjusted closes; return/drawdown/volatility use requested period only; no gap filling')
    return result
