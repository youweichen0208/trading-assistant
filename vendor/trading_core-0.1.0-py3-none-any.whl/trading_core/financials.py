"""Conservative US-GAAP facts: no cumulative-to-quarter inference."""
from datetime import date
import math
import re
import threading
import time
import httpx
from .models import FinancialQuery, DataError, envelope

TAGS = {
    'revenue': ('RevenueFromContractWithCustomerExcludingAssessedTax', 'Revenues', 'SalesRevenueNet'),
    'net_income': ('NetIncomeLoss',),
    'assets': ('Assets',),
    'liabilities': ('Liabilities',),
    'operating_cash_flow': ('NetCashProvidedByUsedInOperatingActivities',),
}
_rate_lock = threading.Lock()
_last_request = 0.0


def _json(client, url):
    global _last_request
    for attempt in range(2):
        with _rate_lock:
            time.sleep(max(0, .25 - (time.monotonic() - _last_request)))
            _last_request = time.monotonic()
        try:
            with client.stream('GET', url) as response:
                if response.status_code == 429:
                    raise DataError('rate_limited')
                if response.status_code in (500,502,503,504) and attempt == 0:
                    continue
                if response.status_code != 200:
                    raise DataError('sec_http_' + str(response.status_code))
                content = bytearray()
                for chunk in response.iter_bytes():
                    content.extend(chunk)
                    if len(content) > 32 * 1024 * 1024:
                        raise DataError('provider_response_too_large')
                import json
                return json.loads(content)
        except httpx.TransportError:
            if attempt:
                raise DataError('sec_connection_failed') from None
        except ValueError:
            raise DataError('invalid_sec_response') from None
    raise DataError('sec_connection_failed')


def _valid(row):
    try:
        return (row.get('form') in {'10-Q','10-Q/A','10-K','10-K/A'}
                and re.fullmatch(r'\d{10}-\d{2}-\d{6}', row['accn']) is not None
                and date.fromisoformat(row['end']) <= date.fromisoformat(row['filed'])
                and isinstance(row['val'], (int,float)) and not isinstance(row['val'], bool)
                and math.isfinite(row['val']))
    except (KeyError, ValueError, TypeError):
        return False


def _duration(row):
    try:
        return (date.fromisoformat(row['end']) - date.fromisoformat(row['start'])).days + 1
    except (KeyError, ValueError, TypeError):
        return 0


def get_financials(query: FinancialQuery, *, user_agent: str, transport=None):
    if not isinstance(query, FinancialQuery):
        raise ValueError('FinancialQuery required')
    if not isinstance(user_agent, str) or not re.fullmatch(r'[^\r\n]{3,180} [^\s@]+@[^\s@]+\.[^\s@]+', user_agent):
        raise DataError('sec_contact_not_configured')
    with httpx.Client(headers={'User-Agent':user_agent,'Accept':'application/json'}, timeout=8,
                      follow_redirects=False, transport=transport) as client:
        mapping = _json(client, 'https://www.sec.gov/files/company_tickers.json')
        matches = [v for v in mapping.values() if v.get('ticker') == query.symbol]
        if len(matches) != 1:
            raise DataError('sec_symbol_not_found')
        cik = int(matches[0]['cik_str'])
        if not 0 < cik < 10**10:
            raise DataError('invalid_sec_response')
        facts = _json(client, f'https://data.sec.gov/api/xbrl/companyfacts/CIK{cik:010d}.json')
        submissions = _json(client, f'https://data.sec.gov/submissions/CIK{cik:010d}.json')
    try:
        if int(facts['cik']) != cik or int(submissions['cik']) != cik:
            raise DataError('sec_identity_mismatch')
        tags = facts.get('facts', {}).get('us-gaap', {})
        recent = submissions['filings']['recent']
        anchors = set()
        for end, form in zip(recent['reportDate'], recent['form']):
            if form in ({'10-K','10-K/A'} if query.frequency == 'annual' else {'10-K','10-K/A','10-Q','10-Q/A'}):
                if end:
                    anchors.add(date.fromisoformat(end).isoformat())
        # Facts retain older reporting periods beyond submissions' recent window.
        for tag in TAGS['revenue'] + TAGS['net_income'] + TAGS['operating_cash_flow']:
            for row in tags.get(tag, {}).get('units', {}).get('USD', []):
                days = _duration(row)
                if _valid(row) and (350 <= days <= 380 or (query.frequency == 'quarterly' and 75 <= days <= 105)):
                    anchors.add(row['end'])
        periods = []
        for end in sorted(anchors, reverse=True)[:query.periods]:
            metrics = {}
            for name, aliases in TAGS.items():
                candidates = []
                present = [tag for tag in aliases if tag in tags]
                for priority, tag in enumerate(aliases):
                    for row in tags.get(tag, {}).get('units', {}).get('USD', []):
                        if not _valid(row) or row['end'] != end:
                            continue
                        duration = _duration(row)
                        if name in {'assets', 'liabilities'}:
                            valid_period = 'start' not in row
                        else:
                            valid_period = (75 <= duration <= 105 if query.frequency == 'quarterly' else 350 <= duration <= 380)
                        if valid_period:
                            candidates.append((row['filed'], -priority, row['accn'], tag, row))
                if not candidates:
                    reason = ('missing_tag' if not present else 'no_usd_unit' if not any('USD' in tags[t].get('units', {}) for t in present)
                              else 'no_explicit_single_quarter' if query.frequency == 'quarterly' else 'no_annual_fact')
                    metrics[name] = dict(value=None, reason=reason)
                    continue
                candidates.sort(key=lambda x:x[:3], reverse=True)
                filed, priority, accession, tag, row = candidates[0]
                same = [r for f,p,a,t,r in candidates if (f,p,a)==(filed,priority,accession)]
                if len({(r.get('start'),r['val']) for r in same}) > 1:
                    metrics[name] = dict(value=None, reason='ambiguous_facts')
                    continue
                metrics[name] = dict(value=row['val'], reason=None, unit='USD', start=row.get('start'), end=end,
                                     filed=filed, accession=accession, form=row['form'], tag='us-gaap:'+tag,
                                     source_url=f'https://www.sec.gov/Archives/edgar/data/{cik}/{accession.replace("-", "")}/{accession}-index.html')
            periods.append(dict(end=end, metrics=metrics))
        result = envelope(query, 'SEC EDGAR Company Facts and submissions')
        result.update(cik=f'{cik:010d}', frequency=query.frequency, periods=periods,
                      period=dict(first=periods[-1]['end'] if periods else None, last=periods[0]['end'] if periods else None),
                      selection='Latest filed eligible USD fact per period/tag; 75–105 day explicit quarters or 350–380 day years; '
                                'instant balances at period end; no subtraction, currency conversion, or Q4 inference.')
        if len(periods) < query.periods:
            result['warnings'].append('Fewer reporting periods available than requested.')
        if any(m['value'] is None for p in periods for m in p['metrics'].values()):
            result['warnings'].append('Missing metrics are retained; cumulative flows are never substituted for quarters.')
        return result
    except (KeyError, ValueError, TypeError, AttributeError):
        raise DataError('invalid_sec_response') from None
