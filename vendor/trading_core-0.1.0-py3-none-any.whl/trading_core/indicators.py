"""Algorithms v1: adjusted closes, simple returns, 252 sessions/year."""
import numpy as np


def calculate_indicators(adjusted_close):
    """Missing prices invalidate the interval; never bridge or forward-fill gaps."""
    prices = np.asarray(adjusted_close, dtype=float)
    if prices.ndim != 1 or len(prices) > 1830:
        raise ValueError("expected at most 1830 daily prices")
    names = ("sma20", "sma50", "sma200", "rsi14", "period_return",
             "annualized_volatility", "max_drawdown")
    if not np.isfinite(prices).all() or (prices <= 0).any():
        return {name: {"value": None, "reason": "missing_or_invalid_adjusted_close"} for name in names}
    def metric(value=None, reason=None):
        return {"value": float(value) if value is not None else None, "reason": reason}
    result = {f"sma{n}": metric(np.mean(prices[-n:])) if len(prices) >= n
              else metric(reason=f"requires_{n}_prices") for n in (20, 50, 200)}
    result["period_return"] = (metric(prices[-1] / prices[0] - 1) if len(prices) >= 2
                               else metric(reason="requires_2_prices"))
    result["max_drawdown"] = (metric(np.min(prices / np.maximum.accumulate(prices) - 1))
                              if len(prices) >= 2 else metric(reason="requires_2_prices"))
    result["annualized_volatility"] = (metric(np.std(prices[1:] / prices[:-1] - 1, ddof=1) * np.sqrt(252))
                                       if len(prices) >= 3 else metric(reason="requires_3_prices"))
    if len(prices) < 15:
        result["rsi14"] = metric(reason="requires_15_prices")
    else:
        changes = np.diff(prices)
        gains, losses = np.maximum(changes, 0), np.maximum(-changes, 0)
        gain, loss = gains[:14].mean(), losses[:14].mean()
        for g, l in zip(gains[14:], losses[14:]):
            gain, loss = (gain * 13 + g) / 14, (loss * 13 + l) / 14
        result["rsi14"] = metric(50 if gain == loss == 0 else 100 if loss == 0 else 100 - 100 / (1 + gain / loss))
    return result
