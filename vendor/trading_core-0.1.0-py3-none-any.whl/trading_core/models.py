from datetime import date, datetime, timezone
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


class Query(BaseModel):
    model_config = ConfigDict(extra="forbid")
    symbol: str = Field(pattern=r"^[A-Z][A-Z0-9]{0,9}(?:[.-][A-Z])?$")


class PriceQuery(Query):
    start: date
    end: date

    @field_validator('start', 'end', mode='before')
    @classmethod
    def date_only(cls, value):
        if not isinstance(value, (str, date)) or isinstance(value, datetime):
            raise ValueError('expected ISO date')
        return value

    @model_validator(mode="after")
    def bounds(self):
        try:
            anniversary = self.start.replace(year=self.start.year + 5)
        except ValueError:
            anniversary = self.start.replace(year=self.start.year + 5, day=28)
        if not self.start < self.end <= min(anniversary, datetime.now(timezone.utc).date()):
            raise ValueError("start inclusive, end exclusive; historical only, at most five years")
        return self


class FinancialQuery(Query):
    frequency: Literal['quarterly', 'annual'] = 'quarterly'
    periods: int = Field(default=4, ge=1, le=8, strict=True)

    @model_validator(mode='after')
    def bounds(self):
        if self.frequency == 'annual' and self.periods > 5:
            raise ValueError('at most five annual periods')
        return self


class DataError(Exception):
    """Only controlled codes cross the public boundary, never provider messages."""
    def __init__(self, code):
        self.code = code
        super().__init__(code)


def envelope(query, source):
    return dict(symbol=query.symbol, source=source, fetched_at=datetime.now(timezone.utc).isoformat(),
                pit=False, warnings=['Latest retrieved history; not formal point-in-time data.'])
